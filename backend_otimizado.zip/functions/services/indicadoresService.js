const {getDb} = require("../repositories/firebaseRepository");
const {normalizeEmpresaId} = require("./tenantService");

async function buscarResumoIndicadores(params = {}) {
  const empresaId = normalizeEmpresaId(params.empresaId);

  if (!empresaId) {
    throw new Error("empresaId e obrigatorio para consultar indicadores.");
  }

  const db = getDb();
  
  // Tentar buscar o dashboard consolidado primeiro (muito mais rápido)
  const dashboardId = `${empresaId.replace(/[^a-zA-Z0-9]/g, "_")}_dashboard`;
  const dashboardSnap = await db.collection("insights").doc(dashboardId).get();
  
  if (dashboardSnap.exists) {
    const data = dashboardSnap.data();
    return mapDashboardToSummary(data, empresaId);
  }

  // Fallback para cálculo em tempo real se o dashboard não existir
  // Nota: Isso é lento e deve ser evitado para grandes volumes de dados
  const [
    rankingSnap,
    curvaSnap,
    rupturaSnap,
    sugestoesSnap,
    mortosSnap,
    alertasSnap,
  ] = await Promise.all([
    getTenantSnap(db, "ranking_vendas", empresaId),
    getTenantSnap(db, "curva_abc", empresaId),
    getTenantSnap(db, "previsao_ruptura", empresaId),
    getTenantSnap(db, "sugestoesCompra", empresaId),
    getTenantSnap(db, "produtos_mortos", empresaId),
    getTenantSnap(db, "alertas", empresaId),
  ]);

  const ranking = summarizeRanking(rankingSnap.docs);
  const curvaAbc = summarizeCurvaAbc(curvaSnap.docs);
  const ruptura = summarizeRuptura(rupturaSnap.docs);
  const sugestoes = summarizeSugestoes(sugestoesSnap.docs);
  const produtosMortos = summarizeProdutosMortos(mortosSnap.docs);
  const alertas = summarizeAlertas(alertasSnap.docs);

  return {
    empresaId,
    isCalculated: true,
    metodologia: "NIQ OSA: disponibilidade de prateleira, ruptura, venda perdida, cobertura, priorizacao por valor e acao por SKU.",
    ranking,
    curvaAbc,
    ruptura,
    sugestoes,
    produtosMortos,
    alertas,
  };
}

function mapDashboardToSummary(data, empresaId) {
  return {
    empresaId,
    isFromDashboard: true,
    metodologia: data.metodologia_indicadores || "NIQ OSA",
    atualizadoEm: data.atualizado_em,
    ranking: {
      totalItens: data.produtos_processados || 0,
      totalVendas: data.total_vendas || 0,
      totalVendasFormatado: data.total_vendas_formatado || "R$ 0,00",
      totalVendas7Dias: data.total_vendas_7_dias || 0,
      totalVendas7DiasFormatado: data.total_vendas_7_dias_formatado || "R$ 0,00",
      vendaPerdidaEstimada: data.venda_perdida_estimada || 0,
      vendaPerdidaEstimadaFormatada: data.venda_perdida_estimada_formatada || "R$ 0,00",
    },
    curvaAbc: {
      classeA: data.curva_abc_itens_classe_a || 0,
      classeB: data.curva_abc_itens_classe_b || 0,
      classeC: data.curva_abc_itens_classe_c || 0,
      percentualItensClasseA: data.curva_abc_percentual_itens_classe_a || 0,
      percentualItensClasseAFormatado: data.curva_abc_percentual_itens_classe_a_formatado || "0%",
      participacaoClasseA: data.curva_abc_faturamento_classe_a_percentual || 0,
      participacaoClasseAFormatada: data.curva_abc_faturamento_classe_a_percentual_formatado || "0%",
    },
    ruptura: {
      totalItens: data.produtos_processados || 0,
      riscoAlto: data.risco_alto || 0,
      riscoMedio: data.risco_medio || 0,
      riscoBaixo: data.risco_baixo || 0,
      ruptura: data.produtos_em_ruptura || 0,
      excessoEstoque: data.excesso_estoque || 0,
      mediaCobertura: data.cobertura_media_dias || 0,
      disponibilidadePrateleira: data.disponibilidade_prateleira || 0,
      disponibilidadePrateleiraFormatada: data.disponibilidade_prateleira_formatada || "0%",
      taxaRuptura: data.taxa_ruptura || 0,
      taxaRupturaFormatada: data.taxa_ruptura_formatada || "0%",
      vendaPerdidaEstimada: data.venda_perdida_estimada || 0,
      vendaPerdidaEstimadaFormatada: data.venda_perdida_estimada_formatada || "R$ 0,00",
    },
    sugestoes: {
      totalItens: data.sugestoes_compra_total_itens || data.sugestoesCompra || 0,
      investimentoSugerido: data.investimento_sugerido || 0,
      investimentoSugeridoFormatado: data.investimento_sugerido_formatado || "R$ 0,00",
    },
    produtosMortos: {
      totalItens: data.produtos_mortos_total_itens || 0,
      estoqueParado: data.produtos_mortos_valor_total_parado || 0,
      vendaPerdidaEstimada: data.venda_perdida_estimada || 0,
      vendaPerdidaEstimadaFormatada: data.venda_perdida_estimada_formatada || "R$ 0,00",
    },
    alertas: {
      totalItens: data.alertas_pendentes || 0,
      pendentes: data.alertas_pendentes || 0,
    }
  };
}

function getTenantSnap(db, collectionName, empresaId) {
  return db
    .collection(collectionName)
    .where("empresa_id", "==", empresaId)
    .get();
}

function summarizeRanking(docs) {
  const items = docs.map((doc) => doc.data());
  const totalVendas = sum(items, "total_vendido");
  const totalVendas7Dias = sum(items, "total_vendido_7_dias");
  const quantidadeVendida = sum(items, "quantidade_vendida");
  const vendaPerdidaEstimada = sum(items, "venda_perdida_estimada");

  return {
    totalItens: items.length,
    totalVendas: round(totalVendas),
    totalVendasFormatado: formatCurrency(totalVendas),
    totalVendas7Dias: round(totalVendas7Dias),
    totalVendas7DiasFormatado: formatCurrency(totalVendas7Dias),
    vendaPerdidaEstimada: round(vendaPerdidaEstimada),
    vendaPerdidaEstimadaFormatada: formatCurrency(vendaPerdidaEstimada),
  };
}

function summarizeCurvaAbc(docs) {
  const counts = {A: 0, B: 0, C: 0};
  let vendaClasseA = 0;
  let vendaTotal = 0;

  for (const doc of docs) {
    const item = doc.data();
    const classe = item.classe || item.abc_classe || "C";
    const totalVendido = Number(item.total_vendido || 0);
    vendaTotal += totalVendido;

    if (classe === "A") {
      counts.A += 1;
      vendaClasseA += totalVendido;
    } else if (classe === "B") {
      counts.B += 1;
    } else {
      counts.C += 1;
    }
  }

  return {
    classeA: counts.A,
    classeB: counts.B,
    classeC: counts.C,
    percentualItensClasseA: docs.length > 0 ? round((counts.A / docs.length) * 100) : 0,
    participacaoClasseA: vendaTotal > 0 ? round((vendaClasseA / vendaTotal) * 100) : 0,
  };
}

function summarizeRuptura(docs) {
  let riscoAlto = 0;
  let riscoMedio = 0;
  let riscoBaixo = 0;
  let ruptura = 0;
  let itensComVenda = 0;
  let itensDisponiveis = 0;
  let somaCobertura = 0;
  let itensComCobertura = 0;
  let vendaPerdidaEstimada = 0;

  for (const doc of docs) {
    const item = doc.data();
    const risco = item.risco || "baixo";
    const estoqueAtual = Number(item.estoque_atual || 0);
    const mediaVendaDia = Number(item.media_venda_dia || 0);
    const perdaItem = Number(item.venda_perdida_estimada || 0);
    const diasCobertura = Number(item.dias_cobertura);

    if (risco === "alto") riscoAlto += 1;
    else if (risco === "medio") riscoMedio += 1;
    else riscoBaixo += 1;

    if (mediaVendaDia > 0) {
      itensComVenda += 1;
      if (estoqueAtual <= 0) ruptura += 1;
    }
    if (estoqueAtual > 0) itensDisponiveis += 1;

    if (Number.isFinite(diasCobertura)) {
      somaCobertura += diasCobertura;
      itensComCobertura += 1;
    }

    if (Number.isFinite(perdaItem)) vendaPerdidaEstimada += perdaItem;
  }

  return {
    totalItens: docs.length,
    riscoAlto,
    riscoMedio,
    riscoBaixo,
    ruptura,
    mediaCobertura: itensComCobertura > 0 ? round(somaCobertura / itensComCobertura) : 0,
    disponibilidadePrateleira: itensComVenda > 0 ? round((itensDisponiveis / itensComVenda) * 100) : 100,
    taxaRuptura: itensComVenda > 0 ? round((ruptura / itensComVenda) * 100) : 0,
    vendaPerdidaEstimada: round(vendaPerdidaEstimada),
  };
}

function summarizeSugestoes(docs) {
  const items = docs.map((doc) => doc.data());
  const investimento = sum(items, "investimento_sugerido");
  return {
    totalItens: items.length,
    investimentoSugerido: round(investimento),
  };
}

function summarizeProdutosMortos(docs) {
  const items = docs.map((doc) => doc.data());
  const estoqueParado = sum(items, "estoque_atual");
  const vendaPerdidaEstimada = sum(items, "venda_perdida_estimada");

  return {
    totalItens: items.length,
    estoqueParado: round(estoqueParado),
    vendaPerdidaEstimada: round(vendaPerdidaEstimada),
  };
}

function summarizeAlertas(docs) {
  const items = docs.map((doc) => doc.data());
  const status = countBy(items, "status");
  return {
    totalItens: items.length,
    pendentes: status.pendente || 0,
  };
}

function sum(items, field) {
  return items.reduce((total, item) => {
    const value = Number(item[field] || 0);
    return total + (Number.isFinite(value) ? value : 0);
  }, 0);
}

function countBy(items, field) {
  return items.reduce((counts, item) => {
    const key = item[field] || "sem_valor";
    counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {});
}

function round(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function formatCurrency(value) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
}

module.exports = {
  buscarResumoIndicadores,
};
