import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'status_badge_widget.dart' show StatusBadgeWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StatusBadgeModel extends FlutterFlowModel<StatusBadgeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
