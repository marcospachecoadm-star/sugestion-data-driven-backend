import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'a_gesto_usuarios_widget.dart' show AGestoUsuariosWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AGestoUsuariosModel extends FlutterFlowModel<AGestoUsuariosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
